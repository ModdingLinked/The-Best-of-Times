Skyrim, Fallout3, FalloutNV, Oblivion
OneTweak - One To Tweak Them All!
==========================================================

OneTweak supports Skyrim, Fallout3, FalloutNV and Oblivion !

Features:
Double Cursor Fix
Borderless Window

Skyrim only:
ShowRaceMenu precache killer

Possible more in future !

Requirments:
SKSE or FOSE or NVSE or OBSE

Usage:
Copy OneTweak.dll and OneTweak.ini to [game install directory]\Data\*SE\Plugins
Where *SE states for SKSE or FOSE or NVSE or OBSE.

Example for Skyrim: [steam directory]\steamapps\common\Skyrim\Data\SKSE\Plugins
NOTE: If some directory does not exist just create it.

Edit Data\SKSE\Plugins\OneTweak.ini to customize settings.

Troubleshooting:
On certain PC's Skyrim freezes/stop responding on loading screen:
- Change Foreground Priority to 2 or 3 in OneTweak.ini

Works even after uninstall:
- Delete Data/SKSE/Plugins/OneTweak.dll then run SkyrimLauncher.exe and in graphics options make sure game is not running in windowed mode. 
