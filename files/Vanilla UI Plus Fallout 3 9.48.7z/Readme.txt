LICENSE
-------
Please read the License.txt file in the mod's archive.

DEPENDENCIES
------------
Base VUI+ for Fallout 3 has no dependencies; the plugin
requires FOSE.

Unlike New Vegas, UIO for Fallout 3 is very old and not
recommeded. If you must use UIO, please remember to always
quit the game from its menu prior to uninstalling any UI mod.

INSTALLATION
------------
The installer should work with any FOMM-compatible manager.

CONFLICTING UI MODS MUST BE INSTALLED BEFORE VUI+ UNLESS THEY
RECOMMEND OTHERWISE. For example, aHUD must be installed
before VUI+ and it must be overwritten by VUI+.

You should also check out the Addons tab at the VUI+ homepage
(moddb.com/mods/vanilla-ui-plus/addons) for compatibility
patches, especially if you're using a custom paperdoll.

After installation you may open the Data\Menus\Prefabs\VUI+\ 
settings.xml file with Notepad++ to set additional options.

You may also open the Data\Menus\Prefabs\VUI+\fonts.xml file
and experiment with the "Menu-specific fonts" entries.

UNINSTALLATION ISSUES
---------------------
If you receive the "Vanilla UI Plus is overwritten" warning after
uninstalling VUI+, then delete your Menus folder and reinstall
any UI mod via right click and "Reinstall".

SUPPORT
-------
VUI+ is supported at moddb.com/mods/vanilla-ui-plus. Please only
report issues that I can reproduce in a minimal load order which
includes all VUI+ dependencies. Try to include a screenshot.

I may ask you to post a link to an archive of your Data\Menus 
folder. This folder doesn't contain personal data and you can use
an ephemeral upload service to post your archive.

To get the contents of Data\Menus in MO2, first download and
install 7zip. Then open MO2, go to Tools > Executables, select
Edit, set a Title, set Binary to C:\Program Files\7-Zip\7zFM.exe,
leave Start In empty, and set Arguments to the game's Data path.
You can now run your custom command and see what the game sees.

CUSTOMIZING KEYBINDS
--------------------
Let's say that you wish to customize the keys for the Quantity
menu to Q for OK and X for Cancel.

First, navigate to the Data\Menus\Prefabs\VUI+\Keybinds folder
and open Quantity.xml with Notepad++. Then make the following
changes:

<_PCButton_Q> QM_OKButton </_PCButton_Q>
<_QM_OKButton> Q) </_QM_OKButton>
<_PCButton_X> QM_CancelButton </_PCButton_X>
<_QM_CancelButton> X) </_QM_CancelButton>

You can now save your changes and test the game. If everything
goes well, you can create a small mod with your custom edits, so
that they won't be overwritten by new VUI+ versions.

CREDITS
-------
VUI+ is dedicated to all users who provided me with useful
feedback. A few names I remember: Ladez, Ermac, Audley, Manan,
Genin, Keleigh, Mortercotic, Bottletopman, Phoenix, Khaileon,
Darthbdaman, Phlunder, HeroinZero, ThatGodlyFellow, EPDGaffney,
Inthegrave, DarianStephens, Jason213, Emptybell, TempNexis, C6,
Ozzyfan, Jake1702, the Icon Guy, StewieAL, Forty7Years, Nehred, 
JustCauseWhyNot, Anro, Trooper, Yvileapsis and others I forget.

Big thanks to Amgame for creating a custom texture file for the
HUD elements.

Thanks to Sebastien Caisse for porting the original game's
font to a high quality truetype version called Fallouty. This
font was included in Van Buren without Red's knowledge.

The fonts have been converted and optimized with the DC Font
Generator utility (nexusmods.com/fallout3/mods/15231).

Additional font mapping fixes have been applied with David Cobb's
Oblivion Font Editor (nexusmods.com/oblivion/mods/48029).

Credits to PipWare UI by Rebb (nexusmods.com/newvegas/mods/34913)
for the original idea of an expanded targeting space around the
scrollbar slider.

The ice cream photo in the logo is courtesy of Anthony Cheung 
(pixabay.com/en/users/anthcheung-4679189).

--
Axonis <axonis@yandex.com>, March 2022